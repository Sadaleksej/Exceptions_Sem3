package org.example;


import java.io.BufferedWriter;
        import java.io.FileWriter;
        import java.io.IOException;
        import java.util.Scanner;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.text.ParseException;



public class Main {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Введите данные через пробел: Фамилия Имя Отчество ДатаРождения НомерТелефона Пол\n" +
                "\n" +
                "Форматы данных:\n" +
                "фамилия, имя, отчество - строки\n" +
                "ДатаРождения - строка формата dd.mm.yyyy\n" +
                "НомерТелефона - целое беззнаковое число без форматирования\n" +
                "пол - символ латиницей f или m.");
        String input = scanner.nextLine();

        String[] data = input.split(" ");
        if (data.length != 6) {
            System.out.println("Ошибка#1: неверное количество данных");
        } else {
            try {
                String lastName = data[0];
                String firstName = data[1];
                String middleName = data[2];
                String birthDate = data[3];
                long phoneNumber = Long.parseLong(data[4]);
                char gender = data[5].charAt(0);

                SimpleDateFormat dateFormat = new SimpleDateFormat("dd.MM.yyyy");

                try {
                    Date date = dateFormat.parse(birthDate);

                } catch (ParseException e) {
                throw new IllegalArgumentException("Ошибка#2: неверный формат даты");}

                if (gender != 'f' && gender != 'm') {
                    throw new IllegalArgumentException("Ошибка#3: неверный формат данных для пола");

                }

                BufferedWriter writer = new BufferedWriter(new FileWriter(lastName + ".txt", true));
                writer.write(lastName + " " + firstName + " " + middleName + " " + birthDate + " " + phoneNumber + " " + gender + System.lineSeparator());
                writer.close();
                System.out.println("Данные успешно записаны в файл " + lastName + ".txt");
            } catch (NumberFormatException e) {
                System.out.println("Ошибка#4: неверный формат данных для номера телефона");
            } catch (IllegalArgumentException e) {
                System.out.println(e.getMessage());
            } catch (IOException e) {
                System.out.println("Ошибка#5 при работе с файлом");
            }
        }
    }
}